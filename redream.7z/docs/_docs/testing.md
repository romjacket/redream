---
title: Testing
---

The `test` directory contains unit tests for some of redream's core data structures, as well as assembly-based tests for the SH4 instruction set.

These tests are compiled and built as the `retest` binary.
