---
title: About
layout: doc
---

redream is a work-in-progress SEGA Dreamcast emulator written in C for Mac, Linux and Windows.

redream is licensed under the [MIT license](https://github.com/inolen/redream/blob/master/LICENSE).

Ask questions and help answer them on [our Slack group](http://slack.redream.io).
